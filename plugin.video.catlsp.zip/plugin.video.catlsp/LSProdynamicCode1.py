# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data, Cookie_Jar, m, list='PLkwBiY2Dq-oYudAQQWU3ene4op723wpxg'):
  import requests
  headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0'}
  apiurl = 'https://www.youtube.com/list_ajax?style=json&action_get_list=1&list={0}&index={1}'
  index = 1
  events = []
  while True:
    page_data = requests.get(apiurl.format(list, index), headers=headers).json()
    items = page_data.get('video')
    index += 200
    for item in items:
      title = item.get('title')
      vid = item.get('encrypted_id')
      info = item.get('description')
      length = item.get('duration')
      thumb = item.get('thumbnail').replace('default', 'hqdefault')
      event = (title, length, info, vid, thumb)
      if event not in events:
        events.append(event)
    if len(events) % 200 != 0:
      return events
